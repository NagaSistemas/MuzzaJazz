﻿// Atualização dos status - apenas 2 status agora
const STATUS_OCUPAM_MESA = ['pago', 'manual'];
const STATUS_CONTA_RECEITA = ['pago'];
